// ==UserScript==
// @name                 Devork Menu [BETA]
// @run-at               document-start
// @version              1.6
// @author               Devork
// @namespace            https://github.com/Devorkk/
// @match                https://www.kogama.com/page/webgl-frame/*
// @match                https://kogama.com.br/page/webgl-frame/*
// @match                https://friends.kogama.com/page/webgl-frame/*
// @require              https://pastebin.com/raw/wY1cfgMQ
// @grant                none
// ==/UserScript==